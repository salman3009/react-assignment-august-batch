import './App.css';
import React from 'react';

function SplitPanel(props){
    return (<div className="container">
        <div className="left-container">
            {props.left}
        </div>
        <div className="right-container">
            {props.right}
        </div>
    </div>)
}

function Contacts(){
   return(<div>
      <h1>Contacts Page</h1>
    </div>)
}

function Help(){
  return(<div>
     <h1>Help Page</h1>
   </div>)
}

function App(){
   return(<SplitPanel left={<Contacts/>} right={<Help/>}/>)
}
export default App;