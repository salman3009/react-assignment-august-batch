import Header from './Header';
import Register from './Register';
import Login from './Login';
import Dashboard from './Dashboard';

function App() {
  return (
    <div className="App">
      <Header/>
      <Register/>
      <Login/>
      <Dashboard/>
    </div>
  );
}

export default App;
