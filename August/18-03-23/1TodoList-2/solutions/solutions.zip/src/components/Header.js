import React from 'react'
import '../styles/App.css';

const Header = () => {
  return (
    <h2 className='header'>To-Do List</h2>
  )
}

export default Header