import React from 'react';


export const Loader = () => <div id="loader">Loading.....</div>